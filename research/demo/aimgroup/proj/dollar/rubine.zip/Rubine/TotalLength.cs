using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public class TotalLength : IFeature
    {

        public const double minValue = 0;
        public const double maxValue = Double.PositiveInfinity;

        public TotalLength()
        {
        }

        public String Name
        {
            get
            {
                return "F8: total length";
            }
        }

        public double MinValue
        {
            get
            {
                return minValue;
            }
        }

        public double MaxValue
        {
            get
            {
                return maxValue;
            }
        }

        public double ComputeValue(Gesture g)
        {
            return Utils.PathLength(g.Points);
        }
    }
}
