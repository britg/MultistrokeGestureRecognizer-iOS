using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Recognizer.Rubine
{
    class Matrix
    {
        /**
         * A new invert routine taken directly from Amulet's gest_matrix.cc
         * (where it's called InvertMatrix).
         * Their comment is:
         * Matrix inversion using full pivoting.
         * The standard Gauss-Jordan method is used.
         * The return value is the determinant.
         * The input matrix may be the same as the result matrix
         *
         *	det = InvertMatrix(inputmatrix, resultmatrix);
         *
         * HISTORY
         * 26-Feb-82  David Smith (drs) at Carnegie-Mellon University
         *	Written.
         * Sun Mar 20 19:36:16 EST 1988 - stolen by dandb,
         * and converted to this form
         */
        public static double Invert(double[,] ym, double[,] rm)
        {

            int i, j, k;
            double det, biga, recip_biga, hold;
            int[] l = new int[ym.GetLength(0)];
            int[] m = new int[ym.GetLength(0)];
            int n;

            if (ym.GetLength(0) != ym.GetLength(1))
            {
                Console.WriteLine("MyInvert: matrix not square");
                return Double.NaN;
            }

            n = ym.GetLength(0);
            if (n != rm.GetLength(0) || n != rm.GetLength(1))
            {
                Console.WriteLine("MyInvert: result wrong size");
                return Double.NaN;
            }

            // copy ym to rm
            Array.Copy(ym, rm, ym.Length);

            // Allocate permutation vectors for l and m, with the same origin as the matrix. 
            det = 1.0;
            for (k = 0; k < n; k++)
            {
                l[k] = k; 
                m[k] = k;
                biga = rm[k, k];

                // Find the biggest element in the submatrix
                for (i = k; i < n; i++)
                {
                    for (j = k; j < n; j++)
                    {
                        if (Math.Abs(rm[i, j]) > Math.Abs(biga))
                        {
                            biga = rm[i, j];
                            l[k] = i;
                            m[k] = j;
                        }
                    }
                }

                // interchange rows
                i = l[k];
                if (i > k)
                {
                    for (j = 0; j < n; j++)
                    {
                        hold = -rm[k, j];
                        rm[k, j] = rm[i, j];
                        rm[i, j] = hold;
                    }
                }

                // interchange columns
                j = m[k];
                if (j > k)
                {
                    for (i = 0; i < n; i++)
                    {
                        hold = -rm[i, k];
                        rm[i, k] = rm[i, j];
                        rm[i, j] = hold;
                    }
                }

                // divide column by minus pivot (value of pivot element is contained in biga)
                if (biga == 0.0)
                {
                    return 0.0;
                }

                recip_biga = 1 / biga;
                for (i = 0; i < n; i++)
                {
                    if (i != k)
                    {
                        rm[i, k] *= -recip_biga;
                    }
                }

                // reduce matrix
                for (i = 0; i < n; i++)
                {
                    if (i != k)
                    {
                        hold = rm[i, k];
                        for (j = 0; j < n; j++)
                        {
                            if (j != k)
                            {
                                rm[i, j] += hold * rm[k, j];
                            }
                        }
                    }
                }

                // divide row by pivot
                for (j = 0; j < n; j++)
                {
                    if (j != k)
                    {
                        rm[k, j] *= recip_biga;
                    }
                }

                det *= biga; // product of pivots

                rm[k,k] = recip_biga;

            }	// k loop

            // final row & column interchanges
            for (k = n - 1; k >= 0; k--)
            {
                i = l[k];
                if (i > k)
                {
                    for (j = 0; j < n; j++)
                    {
                        hold = rm[j, k];
                        rm[j, k] = -rm[j, i];
                        rm[j, i] = hold;
                    }
                }

                j = m[k];
                if (j > k)
                {
                    for (i = 0; i < n; i++)
                    {
                        hold = rm[k, i];
                        rm[k, i] = -rm[j, i];
                        rm[j, i] = hold;
                    }
                }
            }

            return det;
        }

        /**
         * Only works on rectangular matrices.
         * r may be provided or not, as desired.
         */

        public static double[,] Deslice(double[,] m, double fill, BitArray rowMask, BitArray colMask, double[,] r)
        {
            int i, ri, j, rj;
            int nrows = m.GetLength(0);
            int ncols = m.GetLength(1);

            if (r == null)
            {
                r = new double[nrows,ncols];
            }

            Fill(r, fill);
            for (i = 0, ri = 0; i < nrows; i++)
            {
                if (rowMask.Get(i))
                {
                    for (j = 0, rj = 0; j < ncols; j++)
                    {
                        if (colMask.Get(j))
                        {
                            r[i, j] = m[ri, rj++];
                        }
                    }
                    ri++;
                }
            }
            return r;
        }

      /*
       * Only works on rectangular matrices.
       */

      // copied from Amulet's gest_matrix.cc
      public static double[,] Slice(double[,] m, BitArray rowMask, BitArray colMask)
      {
          int i, ri, j, rj;
          int nrows = m.GetLength(0);
          int ncols = m.GetLength(1);
          double[,] r = new double[nrows, ncols];

          for (i = 0, ri = 0; i < nrows; i++)
          {
              if (rowMask.Get(i))
              {
                  for (j = 0, rj = 0; j < ncols; j++)
                  {
                      if (colMask.Get(j))
                      {
                          r[ri, rj++] = m[i, j];
                      }
                  }
                  ri++;
              }
          }

          return r;
      }

        public static void Fill(double[,] m, double fill)
        {
            for (int i = 0; i < m.GetLength(0); i++)
            {
                for (int j = 0; j < m.GetLength(1); j++)
                {
                    m[i, j] = fill;
                }
            }
        }

        public static double QuadraticForm(double[] v, double[,] m)
        {
            double result = 0;
            int n = v.Length;

            if (n != m.GetLength(0) || n != m.GetLength(1))
            {
                Console.WriteLine("Matrix.QuadraticForm: bad matrix size");
                return 0;
            }

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    result += m[i, j] * v[i] * v[j];
                }
            }

            return result;
        }

    }
}
