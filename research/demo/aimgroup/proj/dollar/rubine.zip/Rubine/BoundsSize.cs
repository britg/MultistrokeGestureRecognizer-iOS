using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public class BoundsSize : IFeature
    {
        public const double minValue = 0;
        public const double maxValue = Double.MaxValue;

        public BoundsSize()
        {
        }
  
        public double ComputeValue(Gesture g)
        {
            RectangleR bounds = Utils.FindBox(g.Points);
            return Math.Sqrt((bounds.Width * bounds.Width) + (bounds.Height * bounds.Height)); 
        }

        public String Name
        {
            get
            {
                return "F3: size of bounding box";
            }
        }

        public double MinValue
        {
            get
            {
                return minValue;
            }
        }
  
        public double MaxValue
        {
            get
            {
                return maxValue;
            }
        }
    }
}
