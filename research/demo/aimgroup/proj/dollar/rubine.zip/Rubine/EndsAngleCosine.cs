using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public class EndsAngleCosine : IFeature
    {
        public double minValue = -1;
        public double maxValue = 1;
        double rolloff = (4 * 4);
        double Epsilon = 1e-4;

        public EndsAngleCosine()
        {
        }

        public double ComputeValue(Gesture g)
        {
            double value;

            if (g.Points.Count < 3)
            {
                value = 0;
            }
            else
            {
                PointR startP = (PointR) g.Points[0];
                PointR endP = (PointR) g.Points[g.Points.Count - 1];

                double x0 = startP.X;
                double y0 = startP.Y;
                double xn = endP.X;
                double yn = endP.Y;

                double hypot = Math.Sqrt((xn - x0) * (xn - x0) + (yn - y0) * (yn - y0));
                double factor = hypot * hypot / rolloff;

                if (factor > 1)
                {
                    factor = 1;
                }
                
                factor = (hypot > Epsilon) ? factor / hypot : 0;

                value = (xn - x0) * factor;
            }

            return value;
        }

        public double MinValue
        {
            get
            {
                return minValue;
            }
        }

        public double MaxValue
        {
            get
            {
                return maxValue;
            }
        }

        public String Name
        {
            get
            {
                return "F6: cosine of angle between first and last points";
            }
        }
    }
}
