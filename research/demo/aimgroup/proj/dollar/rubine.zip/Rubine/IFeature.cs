using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public interface IFeature
    {
        String Name { get; }

        double MinValue { get; }

        double MaxValue { get; }

        double ComputeValue(Gesture example);
    }
}
