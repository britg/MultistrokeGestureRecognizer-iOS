using System;
using System.IO;
using System.Xml;
using System.Drawing;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Text;

namespace Recognizer.Rubine
{
    public class RubineRecognizer
    {
        #region Members

        private const double DX = 250.0;
        public static readonly SizeR ResampleScale = new SizeR(DX, DX);
        public static readonly PointR ResampleOrigin = new PointR(0, 0);

        private const double Epsilon = 1E-6; // for singular matrix check
        private static readonly double Phi = (-1 + Math.Sqrt(5)) / 2.0; // Golden Ratio

        private const int NumRandomTests = 100;
        public event ProgressEventHandler ProgressChangedEvent;

        private Hashtable _gestures; // individual strokes (a1, a2, a3, b1, b2, c1)
        private ArrayList _categories; // stroke categories (a, b, c)
        private double[,] _invertedCCM; // inverted common covariance matrix

        private static IFeature[] _featurizers = {
			new InitAngleCosine(), 
            new InitAngleSine(), 
            new BoundsSize(),
			new BoundsAngle(), 
            new EndsDistance(), 
            new EndsAngleCosine(),
            new EndsAngleSine(), 
            new TotalLength(), 
            new TotalAngle(),
            new TotalAbsAngle(), 
            new Sharpness()
        };

        #endregion

        #region Constructor
	
		public RubineRecognizer()
		{
			_gestures = new Hashtable(256);
		}

		#endregion

        #region Initialization and Training

        /// <summary>
        /// Initialize the Rubine recognizer by iterating over the prototypes that are
        /// stored (the training set) and extracting the stroke categories based on
        /// the names of the strokes, then by training on these prototypes and 
        /// categories. Prototype example names are a1, a2, a3, b1, b2, c1; categories
        /// would be a, b, c.
        /// </summary>
        public void Initialize()
        {
            Hashtable catHash = new Hashtable();
            IDictionaryEnumerator ii = _gestures.GetEnumerator();
            while (ii.MoveNext())
            {
                Gesture p = (Gesture) ii.Value;
                string catName = Category.ParseName(p.Name);

                if (catHash.ContainsKey(catName))
                {
                    Category cat = (Category) catHash[catName];
                    cat.AddExample(p); // if the category has been made before, just add to it
                }
                else // create new category
                {
                    catHash.Add(catName, new Category(catName, p));
                }
            }

            // transfer to the list of categories
            _categories = new ArrayList(catHash.Values);

            // the prototypes are loaded and categories determined from their names.
            // now train the recognizer based on these data.
            Train();
        }

        /// <summary>
        /// Train based on the currently loaded prototypes. Resets the current
        /// training-related state.
        /// </summary>
        public void Train()
        {
            int numFeatures = _featurizers.Length;
            int numCategories = _categories.Count;

            // compute all covariance matrices as well as mean vectors
            foreach (Category c in _categories)
            {
                c.Calculate(_featurizers);
            }

            //
            // compute common (average) covariance matrix
            //
            // calculate the denominator
            double denominator = -numCategories;
            foreach (Category c in _categories)
            {
                denominator += c.NumExamples;
            }
            if (denominator <= 0)
            {
                Console.WriteLine("Too few examples - denominator for common covariance matrix is non-positive.");
            }

            // calculate the numerator
            double[,] commonCovarianceMatrix = new double[numFeatures, numFeatures];

            for (int catIdx = 0; catIdx < _categories.Count; catIdx++)
            {
                for (int i = 0; i < numFeatures; i++)
                {
                    for (int j = i; j < numFeatures; j++)
                    {
                        commonCovarianceMatrix[i, j] += ((Category) _categories[catIdx]).CovarianceMatrix[i, j];
                    }
                }
            }

            // divide
            for (int i = 0; i < numFeatures; i++)
            {
                for (int j = i; j < numFeatures; j++)
                {
                    commonCovarianceMatrix[i, j] /= denominator;
                    commonCovarianceMatrix[j, i] = commonCovarianceMatrix[i, j];
                }
            }

            // invert the common covariance matrix
            _invertedCCM = new double[numFeatures, numFeatures];
            double det = Matrix.Invert(commonCovarianceMatrix, _invertedCCM);
            
            // check if determinant is (nearly) zero and fix it if it is
            if (Math.Abs(det) < Epsilon)
            {
                if (!FixClassifier(commonCovarianceMatrix, _invertedCCM)) // try to fix
                {
                    Console.WriteLine("Cannot invert common covariance matrix (determinant = {0}).", det);
                }
            }

            // compute the weights
            for (int index = 0; index < _categories.Count; index++)
            {
                Category category = (Category) _categories[index];
                category.Weights = new double[numFeatures + 1];

                double sum = 0;
                for (int j = 0; j < numFeatures; j++)
                {
                    sum = 0;
                    for (int i = 0; i < numFeatures; i++)
                    {
                        // the column should be changed each time instead - but the inverted matrix is symetric so it doesn't matter
                        sum += _invertedCCM[j, i] * category.MeanVector[i]; // _invertedCCM[j, i] == invertedCCM[i,j];
                    }
                    category.Weights[j + 1] = sum;
                }

                // compute weights[0] differently
                sum = 0;
                for (int i = 0; i < numFeatures; i++)
                {
                    sum += category.Weights[i + 1] * category.MeanVector[i];
                }

                category.Weights[0] = -0.5 * sum;
                // according to amulet code, could add log(priorprobGestureCategory) to weights[gcNum, 0]
            }
        }

        private bool FixClassifier(double[,] ccm, double[,] ccmInv)
        {
            Console.WriteLine("Fixing Classifier becuase the determinant is too small.");

            double det;
            double[,] m;
            double[,] r;
            int numFeatures = _featurizers.Length;

            // at start we're not using any
            BitArray featuresUsed;
            featuresUsed = new BitArray(numFeatures);
            featuresUsed.SetAll(false);

            // add features one-by-one, discarding ones that cause the matrix to be non-invertible
            for (int i = 0; i < numFeatures; i++)
            {
                featuresUsed.Set(i, true);
                m = Matrix.Slice(ccm, featuresUsed, featuresUsed);

                r = new double[numFeatures, numFeatures];
                det = Matrix.Invert(m, r);
                if (Math.Abs(det) <= Epsilon)
                {
                    featuresUsed.Set(i, false);
                }
            }

            m = Matrix.Slice(ccm, featuresUsed, featuresUsed);
            r = new double[numFeatures, numFeatures];
            det = Matrix.Invert(m, r);

            if (Math.Abs(det) <= Epsilon)
                return false;

            Matrix.Deslice(r, 0, featuresUsed, featuresUsed, ccmInv);
            return true;
        }

        #endregion

        #region Recognition

        /// <summary>
        /// Only call this if you know the GestureSet the classifier is using hasn't changed 
        /// since the last time Classify() or Train() was called.  See Classify() for return 
        /// value information.
        /// </summary>
        /// <param name="gesture">The gesture to be classified.</param>
        /// <returns></returns>
        public NBestList Recognize(ArrayList points)
        {
            // rotate so that the centroid-to-1st-point is at zero degrees
            double radians = Utils.AngleInRadians(Utils.Centroid(points), (PointR) points[0], false); // indicative angle
            points = Utils.RotateByRadians(points, -radians); // undo angle

            // scale to a common (square) dimension
            points = Utils.ScaleTo(points, ResampleScale);

            // translate to a common origin
            points = Utils.TranslateCentroidTo(points, ResampleOrigin);
            
            NBestList nbest = new NBestList();
            for (int i = 0; i < _categories.Count; i++)
            {
                Category c = (Category) _categories[i];

                double[] best = GoldenSectionSearch(
                    points,                 // to rotate
                    c,                      // to match
                    Utils.Deg2Rad(-45.0),   // lbound
                    Utils.Deg2Rad(+45.0),   // ubound
                    Utils.Deg2Rad(2.0));    // threshold

                nbest.AddResult(c.Name, best[0], best[1], best[2]); // name, discriminant, distance, angle
            }
            nbest.SortDescending(); // sorts based on discriminant
            return nbest;
        }

        // From http://www.math.uic.edu/~jan/mcs471/Lec9/gss.pdf
        private double[] GoldenSectionSearch(ArrayList pts, Category c, double a, double b, double threshold)
        {
            double x1 = Phi * a + (1 - Phi) * b;
            ArrayList newPoints = Utils.RotateByRadians(pts, x1);
            double dx1;
            double fx1 = ScoreRubine(newPoints, c, out dx1); // higher is better

            double x2 = (1 - Phi) * a + Phi * b;
            newPoints = Utils.RotateByRadians(pts, x2);
            double dx2;
            double fx2 = ScoreRubine(newPoints, c, out dx2); // higher is better

            double i = 2.0; // calls
            while (Math.Abs(b - a) > threshold)
            {
                if (fx1 > fx2) // bigger is better
                {
                    b = x2;
                    x2 = x1;
                    fx2 = fx1;
                    x1 = Phi * a + (1 - Phi) * b;
                    newPoints = Utils.RotateByRadians(pts, x1);
                    fx1 = ScoreRubine(newPoints, c, out dx1);
                }
                else
                {
                    a = x1;
                    x1 = x2;
                    fx1 = fx2;
                    x2 = (1 - Phi) * a + Phi * b;
                    newPoints = Utils.RotateByRadians(pts, x2);
                    fx2 = ScoreRubine(newPoints, c, out dx2);
                }
                i++;
            }

            double angle = Utils.Rad2Deg((b + a) / 2.0);
            return (fx1 > fx2) ? new double[4] { fx1, dx1, angle, i } : new double[4] { fx2, dx2, angle, i };
        }

        private double ScoreRubine(ArrayList points, Category c, out double distance)
        {
            // Compute discriminant.  Higher discriminant -> higher probability that it's the right category.
            double[] featurevector = GetFeatureVector(new Gesture(String.Empty, points));

            double discriminant = c.Weights[0];
            for (int f = 0; f < _featurizers.Length; f++)
            {
                discriminant += c.Weights[f + 1] * featurevector[f];
            }
            distance = MahalanobisDistance(featurevector, c.MeanVector, _invertedCCM);
            return discriminant;
        }

        public double[] GetFeatureVector(Gesture gesture)
        {
            double[] features = new double[_featurizers.Length];
            for (int i = 0; i < features.Length; i++)
            {
                features[i] = _featurizers[i].ComputeValue(gesture);
            }
            return features;
        }

        /// <summary>
        /// Calculate the square of the distance between the two vectors, using the specified dispersion matrix. 
        /// </summary>
        /// <param name="v"></param>
        /// <param name="u"></param>
        /// <param name="sigma"></param>
        /// <returns></returns>
        private double MahalanobisDistance(double[] v, double[] u, double[,] sigma)
        {
            double result;
            double[] space = new double[v.Length];
            for (int i = 0; i < v.Length; i++)
            {
                space[i] = v[i] - u[i];
            }
            result = Matrix.QuadraticForm(space, sigma);
            return result;
        }

        #endregion

        #region Gestures & Xml

        public int NumGestures
        {
            get
            {
                return _gestures.Count;
            }
        }

        public ArrayList Gestures
        {
            get
            {
                ArrayList list = new ArrayList(_gestures.Values);
                list.Sort();
                return list;
            }
        }

        public void ClearGestures()
        {
            if (_gestures != null)
            {
                _gestures.Clear();
            }
            if (_categories != null)
            {
                _categories.Clear();
            }
            if (_invertedCCM != null)
            {
                Array.Clear(_invertedCCM, 0, _invertedCCM.Length);
                _invertedCCM = null;
            }
        }

        public bool SaveGesture(string filename, ArrayList points)
        {
            // add the new prototype with the name extracted from the filename.
            string name = Gesture.ParseName(filename);
            if (_gestures.ContainsKey(name))
                _gestures.Remove(name);
            Gesture newPrototype = new Gesture(name, points);
            _gestures.Add(name, newPrototype);

            // figure out the duration of the gesture
            PointR p0 = (PointR) points[0];
            PointR pn = (PointR) points[points.Count - 1];

            // do the xml writing
            bool success = true;
            XmlTextWriter writer = null;
            try
            {
                // save the prototype as an Xml file
                writer = new XmlTextWriter(filename, Encoding.UTF8);
                writer.Formatting = Formatting.Indented;
                writer.WriteStartDocument(true);
                writer.WriteStartElement("Gesture");
                writer.WriteAttributeString("Name", name);
                writer.WriteAttributeString("NumPts", XmlConvert.ToString(points.Count));
                writer.WriteAttributeString("Millseconds", XmlConvert.ToString(pn.T - p0.T));
                writer.WriteAttributeString("AppName", Assembly.GetExecutingAssembly().GetName().Name);
                writer.WriteAttributeString("AppVer", Assembly.GetExecutingAssembly().GetName().Version.ToString());
                writer.WriteAttributeString("Date", DateTime.Now.ToLongDateString());
                writer.WriteAttributeString("TimeOfDay", DateTime.Now.ToLongTimeString());

                // write out the raw individual points
                foreach (PointR p in points)
                {
                    writer.WriteStartElement("Point");
                    writer.WriteAttributeString("X", XmlConvert.ToString(p.X));
                    writer.WriteAttributeString("Y", XmlConvert.ToString(p.Y));
                    writer.WriteAttributeString("T", XmlConvert.ToString(p.T));
                    writer.WriteEndElement(); // <Point />
                }

                writer.WriteEndDocument(); // </Gesture>
            }
            catch (XmlException xex)
            {
                Console.Write(xex.Message);
                success = false;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                success = false;
            }
            finally
            {
                if (writer != null)
                    writer.Close();
            }
            return success; // Xml file successfully written (or not)
        }

        public bool LoadGesture(string filename)
        {
            bool success = true;
            XmlTextReader reader = null;
            try
            {
                reader = new XmlTextReader(filename);
                reader.WhitespaceHandling = WhitespaceHandling.None;
                reader.MoveToContent();

                Gesture p = ReadGesture(reader);

                // remove any with the same name and add the prototype gesture
                if (_gestures.ContainsKey(p.Name))
                    _gestures.Remove(p.Name);
                _gestures.Add(p.Name, p);
            }
            catch (XmlException xex)
            {
                Console.Write(xex.Message);
                success = false;
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
                success = false;
            }
            finally
            {
                if (reader != null)
                    reader.Close();
            }
            return success;
        }

        // assumes the reader has been just moved to the head of the content.
        private Gesture ReadGesture(XmlTextReader reader)
        {
            Debug.Assert(reader.LocalName == "Gesture");
            string name = reader.GetAttribute("Name");

            ArrayList points = new ArrayList(XmlConvert.ToInt32(reader.GetAttribute("NumPts")));

            reader.Read(); // advance to the first Point
            Debug.Assert(reader.LocalName == "Point");

            while (reader.NodeType != XmlNodeType.EndElement)
            {
                PointR p = PointR.Empty;
                p.X = XmlConvert.ToDouble(reader.GetAttribute("X"));
                p.Y = XmlConvert.ToDouble(reader.GetAttribute("Y"));
                p.T = XmlConvert.ToInt32(reader.GetAttribute("T"));
                points.Add(p);
                reader.ReadStartElement("Point");
            }

            return new Gesture(name, points);
        }

        #endregion

        #region Batch Processing

        /// <summary>
        /// Assemble the gesture filenames into categories that contain 
        /// potentially multiple examples of the same gesture.
        /// </summary>
        /// <param name="filenames"></param>
        /// <returns>A 1D arraylist of category instances that each
        /// contain the same number of examples, or <b>null</b> if an
        /// error occurs.</returns>
        /// <remarks>
        /// See the comments above MainForm.BatchProcess_Click.
        /// </remarks>
        public ArrayList AssembleBatch(string[] filenames)
        {
            Hashtable categories = new Hashtable();

            for (int i = 0; i < filenames.Length; i++)
            {
                string filename = filenames[i];

                XmlTextReader reader = null;
                try
                {
                    reader = new XmlTextReader(filename);
                    reader.WhitespaceHandling = WhitespaceHandling.None;
                    reader.MoveToContent();

                    Gesture p = ReadGesture(reader);
                    string catName = Category.ParseName(p.Name);
                    if (categories.ContainsKey(catName))
                    {
                        Category cat = (Category) categories[catName];
                        cat.AddExample(p); // if the category has been made before, just add to it
                    }
                    else // create new category
                    {
                        categories.Add(catName, new Category(catName, p));
                    }
                }
                catch (XmlException xml)
                {
                    Console.Write(xml.Message);
                    categories.Clear();
                    categories = null;
                }
                catch (Exception ex)
                {
                    Console.Write(ex.Message);
                    categories.Clear();
                    categories = null;
                }
                finally
                {
                    if (reader != null)
                        reader.Close();
                }
            }

            // now make sure that each category has the same number of elements in it
            ArrayList list = null;
            if (categories != null)
            {
                list = new ArrayList(categories.Values);
                int numExamples = ((Category) list[0]).NumExamples;
                foreach (Category c in list)
                {
                    if (c.NumExamples != numExamples)
                    {
                        Console.WriteLine("Different number of examples in gesture categories.");
                        list.Clear();
                        list = null;
                        break;
                    }
                }
            }
            return list;
        }

        /// <summary>
        /// Tests an entire batch of files. See comments atop MainForm.TestBatch_Click().
        /// </summary>
        /// <param name="subject">Subject number.</param>
        /// <param name="speed">"fast", "medium", or "slow"</param>
        /// <param name="categories">A list of gesture categories that each contain lists of
        /// prototypes (examples) within that gesture category.</param>
        /// <param name="dir">The directory into which to write the output files.</param>
        /// <returns>True if successful; false otherwise.</returns>
        public bool TestBatch(int subject, string speed, ArrayList categories, string dir)
        {
            bool success = true;
            StreamWriter mainWriter = null;
            StreamWriter recWriter = null;
            try
            {
                //
                // set up a main results file and detailed recognition results file
                //
                int start = Environment.TickCount;
                string mainFile = String.Format("{0}\\rubine_main_{1}.txt", dir, start);
                string recFile = String.Format("{0}\\rubine_data_{1}.txt", dir, start);

                mainWriter = new StreamWriter(mainFile, false, Encoding.UTF8);
                mainWriter.WriteLine("Subject = {0}, Recognizer = rubine, Speed = {1}, StartTime(ms) = {2}", subject, speed, start);
                mainWriter.WriteLine("Subject Recognizer Speed NumTraining GestureType RecognitionRate\n");

                recWriter = new StreamWriter(recFile, false, Encoding.UTF8);
                recWriter.WriteLine("Subject = {0}, Recognizer = rubine, Speed = {1}, StartTime(ms) = {2}", subject, speed, start);
                recWriter.WriteLine("Correct? NumTrain Tested 1stCorrect Pts Ms Angle : (NBestNames) [NBestScores]\n");

                //
                // determine the number of gesture categories and the number of examples in each one
                //
                int numCategories = categories.Count;
                int numExamples = ((Category) categories[0]).NumExamples;
                double totalTests = (numExamples - 1) * NumRandomTests;

                //
                // outermost loop: trains on N=2..9, tests on 10-N (for e.g., numExamples = 10)
                //
                for (int n = 2; n <= numExamples - 1; n++) // don't train on just N=1
                {
                    // storage for the final avg results for each category for this N
                    double[] results = new double[numCategories];

                    //
                    // run a number of tests at this particular N number of training examples
                    //
                    for (int r = 0; r < NumRandomTests; r++)
                    {
                        ClearGestures(); // clear _gestures and _categories

                        // load (train on) N randomly selected gestures in each category
                        for (int i = 0; i < numCategories; i++)
                        {
                            Category c = (Category) categories[i]; // the category to load N examples for
                            int[] chosen = Utils.Random(0, numExamples - 1, n); // select N unique indices
                            for (int j = 0; j < chosen.Length; j++)
                            {
                                Gesture p = c[chosen[j]]; // get the prototype from this category at chosen[j]
                                _gestures.Add(p.Name, p); // load the randomly selected test gestures into the recognizer
                            }
                        }
                        Initialize(); // train

                        //
                        // testing loop on all unloaded gestures in each category. creates a recognition
                        // rate (%) by averaging the binary outcomes (correct, incorrect) for each test.
                        //
                        for (int i = 0; i < numCategories; i++)
                        {
                            // pick a random unloaded gesture in this category for testing
                            // instead of dumbly picking, first find out what indices aren't
                            // loaded, and then randomly pick from those.
                            Category c = (Category) categories[i];
                            int[] notLoaded = new int[numExamples - n];
                            for (int j = 0, k = 0; j < numExamples; j++)
                            {
                                Gesture g = c[j];
                                if (!_gestures.ContainsKey(g.Name))
                                    notLoaded[k++] = j; // jth gesture in c is not loaded
                            }
                            int chosen = Utils.Random(0, notLoaded.Length - 1); // index
                            Gesture p = c[notLoaded[chosen]]; // gesture to test
                            Debug.Assert(!_gestures.ContainsKey(p.Name));

                            // do the recognition!
                            ArrayList testPts = Utils.RotateByDegrees(p.RawPoints, Utils.Random(0, 359));
                            NBestList result = this.Recognize(testPts);
                            int correct = (c.Name == result.Name) ? 1 : 0;

                            recWriter.WriteLine("{0} {1} {2} {3} {4} {5} {6:F1}{7} : ({8}) [{9}]",
                                correct,                            // Correct?
                                n,                                  // NumTrain 
                                p.Name,                             // Tested 
                                FirstCorrect(p.Name, result.Names), // 1stCorrect
                                p.RawPoints.Count,                  // Pts
                                p.Duration,                         // Ms 
                                Math.Round(result.Angle, 1), (char) 176, // Angle tweaking :
                                result.NamesString,                 // (NBestNames)
                                result.DiscriminantsString);        // [NBestScores]

                            results[i] += correct;
                        }

                        // provide feedback as to how many tests have been performed thus far.
                        double testsSoFar = ((n - 1) * NumRandomTests) + r;
                        ProgressChangedEvent(this, new ProgressEventArgs(testsSoFar / totalTests)); // callback
                    }

                    //
                    // now create the final results for this N and write them to a file
                    //
                    for (int i = 0; i < numCategories; i++)
                    {
                        results[i] /= (double) NumRandomTests; // normalize by the number of tests at this N
                        Category c = (Category) categories[i];
                        // Subject Recognizer Speed NumTraining GestureType RecognitionRate
                        mainWriter.WriteLine("{0} rubine {1} {2} {3} {4:F3}", subject, speed, n, c.Name, Math.Round(results[i], 3));
                    }
                }

                // time-stamp the end of the processing
                int end = Environment.TickCount;
                mainWriter.WriteLine("\nEndTime(ms) = {0}, Minutes = {1}", end, Math.Round((end - start) / 60000.0, 2));
                recWriter.WriteLine("\nEndTime(ms) = {0}, Minutes = {1}", end, Math.Round((end - start) / 60000.0, 2));
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                success = false;
            }
            finally
            {
                if (mainWriter != null)
                    mainWriter.Close();
                if (recWriter != null)
                    recWriter.Close();
            }
            return success;
        }

        private int FirstCorrect(string name, string[] categories)
        {
            string category = Category.ParseName(name);
            for (int i = 0; i < categories.Length; i++)
            {
                if (category == categories[i])
                {
                    return i + 1;
                }
            }
            return -1;
        }

        #endregion
    }
}
