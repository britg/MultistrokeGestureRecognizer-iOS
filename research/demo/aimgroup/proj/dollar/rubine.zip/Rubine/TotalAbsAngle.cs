using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public class TotalAbsAngle : IFeature
    {
        public const double minValue = 0;
        public const double maxValue = Double.PositiveInfinity;
  
        public TotalAbsAngle()
        {
        }

        public String Name
        {
            get
            {
                return "F10: total absolute angle";
            }
        }

       /**
        * Return maximum value this feature can have
        */
        public double MinValue
        {
            get
            {
                return minValue;
            }
        }
  
       /**
        * Return minimum value this feature can have
        */
        public double MaxValue
        {
            get
            {
                return maxValue;
            }
        }

       /**
        * Non-incremental computation. Should set value to new value and valueOk to true.
        */
        public double ComputeValue(Gesture g)
        {
            double value = 0;

            for (int i = 2; i < g.Points.Count; i++)
            {
                PointR pi = (PointR) g.Points[i];
                PointR pi_1 = (PointR) g.Points[i - 1];
                PointR pi_2 = (PointR) g.Points[i - 2];

                double dx = pi.X - pi_1.X;
                double dy = pi.Y - pi_1.Y;
                double dx2 = pi_1.X - pi_2.X;
                double dy2 = pi_1.Y - pi_2.Y;

                double theta = Math.Atan2(dx * dy2 - dx2 * dy, dx * dx2 + dy * dy2);
                value += Math.Abs(theta);
            }

            return value;
        }

    }
}
