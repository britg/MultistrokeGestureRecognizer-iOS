using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace Recognizer.Rubine
{
    public partial class InfoForm : Form
    {
        public InfoForm()
        {
            InitializeComponent();
            cboSpeed.SelectedIndex = 0;
        }

        public int Subject
        {
            get
            {
                return (int) numSubject.Value;
            }
        }

        public string Speed
        {
            get
            {
                return (string) cboSpeed.SelectedItem;
            }
        }
    }
}