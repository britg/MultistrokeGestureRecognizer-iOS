using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public class EndsDistance : IFeature
    {
        public const double minValue = 0;
        public const double maxValue = Double.PositiveInfinity;

        public EndsDistance()
        {

        }

        public String Name
        {
            get
            {
                return "F5: distance between first and last points";
            }
        }

        public double MinValue
        {
            get
            {
                return minValue;
            }
        }

        public double MaxValue
        {
            get
            {
                return maxValue;
            }
        }

        public double ComputeValue(Gesture p)
        {
            double value;
            if (p.Points.Count > 0)
            {
                PointR startP = (PointR) p.Points[0];
                PointR endP = (PointR) p.Points[p.Points.Count - 1];
                value = Utils.Distance(endP, startP);
            }
            else
            {
                value = 0;
            }
            return value;
        }
    }
}
