using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public class InitAngleCosine : IFeature
    {
        public double minValue = -1;
        public double maxValue = 1;

        public InitAngleCosine()
        {
        }

        public double MinValue
        {
            get
            {
                return minValue;
            }
        }

        public double MaxValue
        {
            get
            {
                return maxValue;
            }
        }

        public double ComputeValue(Gesture g)
        {
            if (g.Points.Count < 3)
            {
                return 0;
            }
            else
            {
                PointR first = (PointR) g.Points[0];
                PointR third = (PointR) g.Points[2];

                double x0 = first.X;
                double y0 = first.Y;
                double x2 = third.X;
                double y2 = third.Y;

                double hypot = Math.Sqrt((x2 - x0) * (x2 - x0) + (y2 - y0) * (y2 - y0));
                return (hypot == 0) ? 0 : (x2 - x0) / hypot;
            }
        }

        public String Name
        {
            get
            {
                return "F1: cosine of initial angle";
            }
        }
    }
}
