using System;
using System.Collections.Generic;
using System.Text;

namespace Recognizer.Rubine
{
    public class BoundsAngle : IFeature
    {
         public const double minValue = 0;
         public const double maxValue = Math.PI / 2.0;

        public BoundsAngle()
        {
        }

        public String Name
        {
            get
            {
                return "F4: angle of bounding box";
            }
        }

        public double MinValue
        {
            get
            {
                return minValue;
            }
        }
  
        public double MaxValue
        {
            get
            {
                return maxValue;
            }
        }

        public double ComputeValue(Gesture g)
        {
            RectangleR bounds = Utils.FindBox(g.Points);
            return Math.Atan2(bounds.Height, bounds.Width);
        }
    }
}
