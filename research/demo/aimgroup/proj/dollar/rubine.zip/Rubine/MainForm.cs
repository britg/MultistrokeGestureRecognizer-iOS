using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace Recognizer.Rubine
{
	public class MainForm : System.Windows.Forms.Form
	{
		#region Fields

        private RubineRecognizer    _rec;
		private bool				_recording;
		private bool				_isDown;
		private ArrayList			_points;
		private ViewForm			_viewFrm;

		#endregion

		#region Form Elements

		private System.Windows.Forms.Label lblRecord;
		private System.Windows.Forms.MainMenu MainMenu;
		private System.Windows.Forms.MenuItem Exit;
		private System.Windows.Forms.MenuItem Separator0;
		private System.Windows.Forms.MenuItem LoadGesture;
		private System.Windows.Forms.MenuItem ViewGesture;
		private System.Windows.Forms.MenuItem RecordGesture;
		private System.Windows.Forms.MenuItem GestureMenu;
        private System.Windows.Forms.MenuItem ClearGesture;
		private System.Windows.Forms.Label lblResult;
		private System.Windows.Forms.MenuItem HelpMenu;
        private System.Windows.Forms.MenuItem About;
        private Label lblRecognizing;
        private MenuItem FileMenu;
        private MenuItem TestBatch;
        private ProgressBar prgTesting;
        private IContainer components;

		#endregion

        #region Start & Stop

        [STAThread]
        static void Main(string[] args)
        {
            Application.Run(new MainForm());
        }

        public MainForm()
        {
			SetStyle(ControlStyles.DoubleBuffer | ControlStyles.AllPaintingInWmPaint | ControlStyles.UserPaint, true);
			InitializeComponent();
            _rec = new RubineRecognizer();
            _rec.ProgressChangedEvent += new ProgressEventHandler(OnProgressChanged);
			_points = new ArrayList(256);
			_viewFrm = null;
		}

		protected override void Dispose(bool disposing)
		{
			if (disposing)
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose(disposing);
        }

        #endregion

        #region Windows Form Designer generated code
        /// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
            this.components = new System.ComponentModel.Container();
            this.lblRecord = new System.Windows.Forms.Label();
            this.MainMenu = new System.Windows.Forms.MainMenu(this.components);
            this.FileMenu = new System.Windows.Forms.MenuItem();
            this.Exit = new System.Windows.Forms.MenuItem();
            this.GestureMenu = new System.Windows.Forms.MenuItem();
            this.RecordGesture = new System.Windows.Forms.MenuItem();
            this.LoadGesture = new System.Windows.Forms.MenuItem();
            this.ViewGesture = new System.Windows.Forms.MenuItem();
            this.ClearGesture = new System.Windows.Forms.MenuItem();
            this.Separator0 = new System.Windows.Forms.MenuItem();
            this.TestBatch = new System.Windows.Forms.MenuItem();
            this.HelpMenu = new System.Windows.Forms.MenuItem();
            this.About = new System.Windows.Forms.MenuItem();
            this.lblResult = new System.Windows.Forms.Label();
            this.lblRecognizing = new System.Windows.Forms.Label();
            this.prgTesting = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // lblRecord
            // 
            this.lblRecord.BackColor = System.Drawing.Color.Transparent;
            this.lblRecord.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRecord.Font = new System.Drawing.Font("Courier New", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte) (0)));
            this.lblRecord.ForeColor = System.Drawing.Color.Firebrick;
            this.lblRecord.Location = new System.Drawing.Point(0, 0);
            this.lblRecord.Name = "lblRecord";
            this.lblRecord.Size = new System.Drawing.Size(352, 24);
            this.lblRecord.TabIndex = 1;
            this.lblRecord.Text = "[Recording]";
            this.lblRecord.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblRecord.Visible = false;
            // 
            // MainMenu
            // 
            this.MainMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.FileMenu,
            this.GestureMenu,
            this.HelpMenu});
            // 
            // FileMenu
            // 
            this.FileMenu.Index = 0;
            this.FileMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.Exit});
            this.FileMenu.Text = "&File";
            // 
            // Exit
            // 
            this.Exit.Index = 0;
            this.Exit.Text = "E&xit";
            this.Exit.Click += new System.EventHandler(this.Exit_Click);
            // 
            // GestureMenu
            // 
            this.GestureMenu.Index = 1;
            this.GestureMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.RecordGesture,
            this.LoadGesture,
            this.ViewGesture,
            this.ClearGesture,
            this.Separator0,
            this.TestBatch});
            this.GestureMenu.Text = "&Gestures";
            this.GestureMenu.Popup += new System.EventHandler(this.GestureMenu_Popup);
            // 
            // RecordGesture
            // 
            this.RecordGesture.Index = 0;
            this.RecordGesture.Shortcut = System.Windows.Forms.Shortcut.CtrlR;
            this.RecordGesture.Text = "&Record";
            this.RecordGesture.Click += new System.EventHandler(this.RecordGesture_Click);
            // 
            // LoadGesture
            // 
            this.LoadGesture.Index = 1;
            this.LoadGesture.Shortcut = System.Windows.Forms.Shortcut.CtrlO;
            this.LoadGesture.Text = "&Load...";
            this.LoadGesture.Click += new System.EventHandler(this.LoadGesture_Click);
            // 
            // ViewGesture
            // 
            this.ViewGesture.Index = 2;
            this.ViewGesture.Shortcut = System.Windows.Forms.Shortcut.CtrlV;
            this.ViewGesture.Text = "&View";
            this.ViewGesture.Click += new System.EventHandler(this.ViewGesture_Click);
            // 
            // ClearGesture
            // 
            this.ClearGesture.Index = 3;
            this.ClearGesture.Text = "&Clear";
            this.ClearGesture.Click += new System.EventHandler(this.ClearGestures_Click);
            // 
            // Separator0
            // 
            this.Separator0.Index = 4;
            this.Separator0.Text = "-";
            // 
            // TestBatch
            // 
            this.TestBatch.Index = 5;
            this.TestBatch.Shortcut = System.Windows.Forms.Shortcut.CtrlT;
            this.TestBatch.Text = "&Test Batch...";
            this.TestBatch.Click += new System.EventHandler(this.TestBatch_Click);
            // 
            // HelpMenu
            // 
            this.HelpMenu.Index = 2;
            this.HelpMenu.MenuItems.AddRange(new System.Windows.Forms.MenuItem[] {
            this.About});
            this.HelpMenu.Text = "&Help";
            // 
            // About
            // 
            this.About.Index = 0;
            this.About.Text = "&About Recognizer";
            this.About.Click += new System.EventHandler(this.About_Click);
            // 
            // lblResult
            // 
            this.lblResult.AutoSize = true;
            this.lblResult.Dock = System.Windows.Forms.DockStyle.Right;
            this.lblResult.Location = new System.Drawing.Point(324, 24);
            this.lblResult.Name = "lblResult";
            this.lblResult.Size = new System.Drawing.Size(28, 13);
            this.lblResult.TabIndex = 2;
            this.lblResult.Text = "Test";
            this.lblResult.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblRecognizing
            // 
            this.lblRecognizing.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblRecognizing.ForeColor = System.Drawing.Color.Firebrick;
            this.lblRecognizing.Location = new System.Drawing.Point(0, 24);
            this.lblRecognizing.Name = "lblRecognizing";
            this.lblRecognizing.Size = new System.Drawing.Size(324, 23);
            this.lblRecognizing.TabIndex = 3;
            this.lblRecognizing.Text = "Recognizing...";
            this.lblRecognizing.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lblRecognizing.Visible = false;
            // 
            // prgTesting
            // 
            this.prgTesting.Location = new System.Drawing.Point(0, 141);
            this.prgTesting.Name = "prgTesting";
            this.prgTesting.Size = new System.Drawing.Size(352, 23);
            this.prgTesting.TabIndex = 4;
            this.prgTesting.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
            this.BackColor = System.Drawing.SystemColors.Window;
            this.ClientSize = new System.Drawing.Size(352, 305);
            this.Controls.Add(this.prgTesting);
            this.Controls.Add(this.lblRecognizing);
            this.Controls.Add(this.lblResult);
            this.Controls.Add(this.lblRecord);
            this.Menu = this.MainMenu;
            this.Name = "MainForm";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Show;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Recognizer.Rubine";
            this.Paint += new System.Windows.Forms.PaintEventHandler(this.MainForm_Paint);
            this.MouseUp += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseUp);
            this.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseMove);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.MainForm_MouseDown);
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

		}
		#endregion

        #region Form Events

        private void MainForm_Load(object sender, EventArgs e)
        {
            lblResult.Text = String.Empty;
        }

        private void MainForm_Paint(object sender, System.Windows.Forms.PaintEventArgs e)
		{
            if (_points.Count > 0)
            {
                PointF p0 = (PointF) (PointR) _points[0]; // draw the first point bigger
                e.Graphics.FillEllipse(_recording ? Brushes.Firebrick : Brushes.DarkBlue, p0.X - 5f, p0.Y - 5f, 10f, 10f);
            }
			foreach (PointR r in _points)
			{
				PointF p = (PointF) r; // cast
				e.Graphics.FillEllipse(_recording ? Brushes.Firebrick : Brushes.DarkBlue, p.X - 2f, p.Y - 2f, 4f, 4f);
			}
		}

        #endregion

        #region File Menu

        private void Exit_Click(object sender, System.EventArgs e)
        {
            Close();
        }

        #endregion

        #region Gesture Menu

        private void GestureMenu_Popup(object sender, EventArgs e)
        {
            RecordGesture.Checked = _recording;
            ViewGesture.Checked = (_viewFrm != null && !_viewFrm.IsDisposed);
            ClearGesture.Enabled = (_rec.NumGestures > 0);
        }

        private void RecordGesture_Click(object sender, EventArgs e)
        {
            _points.Clear();
            Invalidate();
            _recording = !_recording;
            lblRecord.Visible = _recording;
        }

        private void LoadGesture_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Gestures (*.xml)|*.xml";
            dlg.Title = "Load Gestures";
            dlg.Multiselect = true;
            dlg.RestoreDirectory = false;

            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                for (int i = 0; i < dlg.FileNames.Length; i++)
                {
                    string name = dlg.FileNames[i];
                    _rec.LoadGesture(name);
                }
                _rec.Initialize(); // re-train the recognizer in light of the new prototypes
                ReloadViewForm();
            }
        }

        private void ClearGestures_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show(this, "This will clear all loaded gestures. (It will not delete any XML files.)", "Confirm", MessageBoxButtons.OKCancel, MessageBoxIcon.Warning) == DialogResult.OK)
            {
                _rec.ClearGestures();
                ReloadViewForm();
            }
        }

        private void ViewGesture_Click(object sender, EventArgs e)
        {
            if (_viewFrm != null && !_viewFrm.IsDisposed)
            {
                _viewFrm.Close();
                _viewFrm = null;
            }
            else
            {
                _viewFrm = new ViewForm(_rec.Gestures);
                _viewFrm.Owner = this;
                _viewFrm.Show();
            }
        }

        // helper fn
        private void ReloadViewForm()
        {
            if (_viewFrm != null && !_viewFrm.IsDisposed)
            {
                _viewFrm.Close();
                _viewFrm = new ViewForm(_rec.Gestures);
                _viewFrm.Owner = this;
                _viewFrm.Show();
            }
        }

        /// <summary>
        /// This menu command allows the user to multi-select a handful of
        /// gesture XML files from a directory, and to produce an output
        /// file containing the recognition results for everything in the
        /// directory.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        /// <remarks>
        /// The gestures loaded must conform to a naming convention
        /// where each example of a particular gesture is named with
        /// the same string, followed by a numerical identifier for
        /// that example. As in:
        ///
        ///     circle01.xml        // circle gestures
        ///     circle02.xml
        ///     circle03.xml
        ///     square01.xml        // square gestures
        ///     square02.xml
        ///     square03.xml
        ///     triangle01.xml      // triangle gestures
        ///     triangle02.xml
        ///     triangle03.xml
        ///
        /// The same number of examples should be read in for each gesture
        /// category. The testing procedure will load a random subset of
        /// each gesture and test on the remaining gestures.
        /// 
        /// <b>Warning.</b> This process will throw an exception if the number
        /// of gesture examples for each gesture is unbalanced.
        /// </remarks>
        private void TestBatch_Click(object sender, EventArgs e)
        {
            OpenFileDialog dlg = new OpenFileDialog();
            dlg.Filter = "Gestures (*.xml)|*.xml";
            dlg.Title = "Load Gesture Batch";
            dlg.RestoreDirectory = false;
            dlg.Multiselect = true;

            if (dlg.ShowDialog(this) == DialogResult.OK)
            {
                InfoForm ifrm = new InfoForm();
                if (ifrm.ShowDialog(this) == DialogResult.OK)
                {
                    prgTesting.Visible = true;
                    lblRecognizing.Visible = true;
                    Application.DoEvents();

                    // each slot in the ArrayList contains a gesture Category, which 
                    // contains an ArrayList of gesture prototypes.
                    ArrayList categories = _rec.AssembleBatch(dlg.FileNames);

                    if (categories != null)
                    {
                        if (_rec.TestBatch(ifrm.Subject, ifrm.Speed, categories, dlg.FileName.Substring(0, dlg.FileName.LastIndexOf('\\'))))
                        {
                            MessageBox.Show(this, "Testing complete.", "Complete", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show(this, "There was an error writing the output file during testing.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                    else // error assembling batch
                    {
                        MessageBox.Show(this, "Unreadable files, or unbalanced number of gestures in categories.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    lblRecognizing.Visible = false;
                    prgTesting.Visible = false;
                }
            }
        }

        // update the progress bar upon receiving this event (callback)
        public void OnProgressChanged(object source, ProgressEventArgs e)
        {
            prgTesting.Value = (int) (e.Percent * 100d);
            Application.DoEvents();
        }

        #endregion

        #region Help Menu

        private void About_Click(object sender, System.EventArgs e)
		{
			AboutForm frm = new AboutForm(_points);
			frm.ShowDialog(this);
        }

        #endregion

        #region Mouse Events

        private void MainForm_MouseDown(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            _isDown = true;
            _points.Clear();
            _points.Add(new PointR(e.X, e.Y, Environment.TickCount));
            Invalidate();
        }

        private void MainForm_MouseMove(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (_isDown)
            {
                _points.Add(new PointR(e.X, e.Y));
                Invalidate(new Rectangle(e.X - 2, e.Y - 2, 4, 4));
            }
        }

        private void MainForm_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
        {
            if (_isDown)
            {
                _isDown = false;

                if (_points.Count >= 5) // require 5 points for a valid gesture
                {
                    if (_recording)
                    {
                        SaveFileDialog dlg = new SaveFileDialog();
                        dlg.Filter = "Gestures (*.xml)|*.xml";
                        dlg.Title = "Save Gesture As";
                        dlg.AddExtension = true;
                        dlg.RestoreDirectory = false;

                        if (dlg.ShowDialog(this) == DialogResult.OK)
                        {
                            _rec.SaveGesture(dlg.FileName, _points);  // resample, scale, translate to origin
                            _rec.Initialize();
                            ReloadViewForm();
                        }

                        dlg.Dispose();
                        _recording = false;
                        lblRecord.Visible = false;
                        Invalidate();
                    }
                    else if (_rec.NumGestures > 0) // not recording, so testing
                    {
                        lblRecognizing.Visible = true;
                        Application.DoEvents(); // forces label to display

                        NBestList result = _rec.Recognize(_points);
                        lblResult.Text = String.Format("{0}: {1} ({2}px, {3}{4})",
                            result.Name,
                            Math.Round(result.Discriminant, 2),
                            Math.Round(result.Distance, 2),
                            Math.Round(result.Angle, 2), (char) 176);

                        lblRecognizing.Visible = false;
                    }
                }
            }
        }

        #endregion

    }
}
