/*
 * geometry.h - Geometric primitives and functions
 *
 *   Copyright (c) 2008  Takanori Ishikawa  <takanori.ishikawa@gmail.com>
 *
 *   Permission is hereby granted, free of charge, to any person obtaining a copy
 *   of this software and associated documentation files (the "Software"), to deal
 *   in the Software without restriction, including without limitation the rights
 *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *   copies of the Software, and to permit persons to whom the Software is
 *   furnished to do so, subject to the following conditions:
 *
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 *
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *   THE SOFTWARE.
 */

#ifndef DOLLAR_GEOMETRY_H
#define DOLLAR_GEOMETRY_H

#include <dollar/base.h>
#include <float.h>


#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */


#if defined(__APPLE__) && !defined(NO_CORE_GRAPHICS) /* Apple Mac OS X or iPhone/iPod touch */

/*
 * For CoreGraphics framework, GRGeometry.h
 *
 * ApplicationServices.framework contains pointer to the CoreGraphics.framework
 * in Mac OS X, in iPhone OS, however, there is ApplicationServices.framework
 * available on iPhone simulator only.
 *
 * See "iPhone OS Technology Overview" Appendix B: iPhone OS Frameworks
 */
#include <TargetConditionals.h>
#if TARGET_OS_IPHONE || TARGET_IPHONE_SIMULATOR
# include <CoreGraphics/CoreGraphics.h>
#else /* TARGET_OS_IPHONE || TARGET_OS_IPHONE */
# include <ApplicationServices/ApplicationServices.h>
#endif /* TARGET_OS_IPHONE || TARGET_OS_IPHONE */

typedef CGFloat GRFloat;
typedef CGPoint GRPoint;
typedef CGSize  GRSize;
typedef CGRect  GRRect;

/* Minimum normalized positive floating-point number, b**(emin - 1). */
#define GRFLOAT_MIN CGFLOAT_MIN
/* Maximum representable finite floating-point number. */
#define GRFLOAT_MAX CGFLOAT_MAX


/* ----------------------------------------------------------------
 * Geometry Inline Functions
 * ---------------------------------------------------------------- */
#define GRPointMake CGPointMake
#define GRSizeMake  CGSizeMake
#define GRRectMake  CGRectMake

#define GRRectGetMinX   CGRectGetMinX
#define GRRectGetMinY   CGRectGetMinY
#define GRRectGetWidth  CGRectGetWidth
#define GRRectGetHeight CGRectGetHeight

#else /* __APPLE__ */

typedef float GRFloat;

/** Point */
typedef struct {
  GRFloat x;
  GRFloat y;
} GRPoint;

/** Size */
typedef struct {
  GRFloat width;
  GRFloat height;
} GRSize;

/** Rectangle */
typedef struct {
  GRPoint origin;
  GRSize size;
} GRRect;


/* Minimum normalized positive floating-point number, b**(emin - 1). */
#define GRFLOAT_MIN FLT_MIN
/* Maximum representable finite floating-point number. */
#define GRFLOAT_MAX FLT_MAX


/* ----------------------------------------------------------------
 * Geometry Inline Functions
 * ---------------------------------------------------------------- */
/**
 * Returns a GRPoint structure, representing a single (x,y) coordinate pair.
 */
GR_INLINE GRPoint GRPointMake(GRFloat x, GRFloat y) {
  GRPoint p; p.x = x; p.y = y; return p;
}

/**
 * Returns a GRSize structure filled in with dimension values you provide.
 */
GR_INLINE GRSize GRSizeMake(GRFloat width, GRFloat height) {
  GRSize size; size.width = width; size.height = height; return size;
}

/**
 * Returns a GRRect structure filled in with the coordinate and
 * dimension values you provide.
 */
GR_INLINE GRRect GRRectMake(GRFloat x, GRFloat y, GRFloat width, GRFloat height) {
  GRRect rect;
  rect.origin.x = x; rect.origin.y = y;
  rect.size.width = width; rect.size.height = height;
  return rect;
}


/** Returns the x origin of rectangle */
GR_INLINE GRFloat GRRectGetMinX(GRRect rect) {
  return rect.origin.x;
}

/** Returns the y origin of rectangle */
GR_INLINE GRFloat GRRectGetMinY(GRRect rect) {
  return rect.origin.y;
}

/** Returns the width of a rectangle. */
GR_INLINE GRFloat GRRectGetWidth(GRRect rect) {
  return rect.size.width;
}

/** Returns the height of a rectangle. */
GR_INLINE GRFloat GRRectGetHeight(GRRect rect) {
  return rect.size.height;
}

#endif /* __APPLE__ */


#ifdef __cplusplus
} /* extern "C" { */
#endif /* __cplusplus */
#endif /* DOLLAR_GEOMETRY_H */
