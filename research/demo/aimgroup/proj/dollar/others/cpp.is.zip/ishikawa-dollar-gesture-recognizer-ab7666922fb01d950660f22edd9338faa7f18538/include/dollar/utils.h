/*
 * utils.h - Utilities
 *
 *   Copyright (c) 2008  Takanori Ishikawa  <takanori.ishikawa@gmail.com>
 *
 *   Permission is hereby granted, free of charge, to any person obtaining a copy
 *   of this software and associated documentation files (the "Software"), to deal
 *   in the Software without restriction, including without limitation the rights
 *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *   copies of the Software, and to permit persons to whom the Software is
 *   furnished to do so, subject to the following conditions:
 *
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 *
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *   THE SOFTWARE.
 */

#ifndef DOLLAR_UTILS_H
#define DOLLAR_UTILS_H

#include <dollar/base.h>
#include <dollar/geometry.h>


/**
 * This file contains utility functions in GestureRecognizer namespace.
 * Note that these implementations are not overflow/underflow safe.
 */
namespace GestureRecognizer {

  /** GRPoint iterator */
  typedef GRPoint *point_iter;
  typedef const GRPoint *const_point_iter;

  /** Converts degrees to radians */
  inline double convertDegreeToRadian(double degrees) throw() {
    return degrees * M_PI / 180.0;
  }

  /** Converts radians to degrees */
  inline double convertRadianToDegree(double radians) throw() {
    return radians * 180.0 / M_PI;
  }

  /** Returns a distance between p1 and p2 */
  GRFloat distance(const GRPoint& p1, const GRPoint& p2) throw();

  /* Returns a path length of specified points between begin and end */
  GRFloat pathLength(const_point_iter begin, const_point_iter end) throw();

  /**
   * Computes a distance between two paths by averaging their corresponding
   * point distances.
   * Note: Assume that each path has been resampled to the same number of
   * points at the same distance apart.
   */
  GRFloat pathDistance(
    const_point_iter pts1Begin, const_point_iter pts1End,
    const_point_iter pts2Begin, const_point_iter pts2End) throw();

  /** Returns the centroid, geometric center of points */
  GRPoint centroid(const_point_iter begin, const_point_iter end) throw();

  /** Returns minimum rectangle contains specified points */
  GRRect boundingBox(const_point_iter begin, const_point_iter end) throw();

  /**
   * Rotates specified points by angle radians, replacing specified points
   * with the result.
   */
  void rotateByRadians(point_iter begin, point_iter end, double angleRadians) throw();

  /**
   * Rotates specified points by angle degrees, replacing specified points
   * with the result.
   */
  void rotateByDegrees(point_iter begin, point_iter end, double angleDegrees) throw();

  /**
   * Returns the angle between point start and end.
   */
  double angleInRadians(const GRPoint& start, const GRPoint& end, bool positiveOnly = false) throw();

} /* namespace GestureRecognizer */


#endif /* DOLLAR_UTILS_H */
