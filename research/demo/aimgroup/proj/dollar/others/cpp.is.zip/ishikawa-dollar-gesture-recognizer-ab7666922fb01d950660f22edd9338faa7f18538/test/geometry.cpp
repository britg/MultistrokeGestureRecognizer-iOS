/*
 * geometry.cpp
 *
 *   Copyright (c) 2008  Takanori Ishikawa  <takanori.ishikawa@gmail.com>
 *
 *   Permission is hereby granted, free of charge, to any person obtaining a copy
 *   of this software and associated documentation files (the "Software"), to deal
 *   in the Software without restriction, including without limitation the rights
 *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *   copies of the Software, and to permit persons to whom the Software is
 *   furnished to do so, subject to the following conditions:
 *
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 *
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *   THE SOFTWARE.
 */

#include "./unittest.h"


namespace {

using namespace GestureRecognizer::Test;

void test_GRPointMake() {
  GRPoint p = GRPointMake(10.0f, 20.0f);
  assertAlmostEqual(p.x, 10.0);
  assertAlmostEqual(p.y, 20.0);
}

void test_GRSizeMake() {
  GRSize s = GRSizeMake(10.0f, 20.0f);
  assertAlmostEqual(s.width,  10.0);
  assertAlmostEqual(s.height, 20.0);
}

void test_GRRectMake() {
  GRRect r = GRRectMake(10.0f, 20.0f, 30.0f, 40.0f);
  assertAlmostEqual(r.origin.x, 10.0);
  assertAlmostEqual(r.origin.y, 20.0);
  assertAlmostEqual(r.size.width,  30.0);
  assertAlmostEqual(r.size.height, 40.0);
}

void test_GRRectGetWidthHeight() {
  GRRect r = GRRectMake(10.0f, 20.0f, 30.0f, 40.0f);
  assertAlmostEqual(GRRectGetWidth(r),  30.0);
  assertAlmostEqual(GRRectGetHeight(r), 40.0);
}

} /* anonymous namespace */


namespace GestureRecognizer {
  namespace Test {

    void runGeometryTest() {
      test_GRPointMake();
      test_GRSizeMake();
      test_GRRectMake();
      test_GRRectGetWidthHeight();
    }

  } /* namespace Test */
} /* namespace GestureRecognizer */
