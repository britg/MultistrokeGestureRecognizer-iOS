/*
 * utils.cpp - Utilities
 *
 *   Copyright (c) 2008  Takanori Ishikawa  <takanori.ishikawa@gmail.com>
 *
 *   Permission is hereby granted, free of charge, to any person obtaining a copy
 *   of this software and associated documentation files (the "Software"), to deal
 *   in the Software without restriction, including without limitation the rights
 *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *   copies of the Software, and to permit persons to whom the Software is
 *   furnished to do so, subject to the following conditions:
 *
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 *
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *   THE SOFTWARE.
 */

#include <dollar/utils.h>
#include <cmath>


namespace GestureRecognizer {

GRFloat distance(const GRPoint& p1, const GRPoint& p2) throw() {
  const GRFloat dx = p2.x - p1.x;
  const GRFloat dy = p2.y - p1.y;
  return sqrt(dx * dx + dy * dy);
}

GRFloat pathLength(const_point_iter begin, const_point_iter end) throw() {
  GRFloat d = 0.0;

  if (begin != end) {
    for (const_point_iter p = begin+1; p != end; ++p) {
      d += distance(*(p-1), *p);
    }
  }
  return d;
}

GRFloat pathDistance(
  const_point_iter pts1Begin, const_point_iter pts1End,
  const_point_iter pts2Begin, const_point_iter pts2End) throw()
{
  GRFloat d = 0.0;
  std::size_t size = 0;

  for (const_point_iter p1 = pts1Begin, p2 = pts2Begin;
       p1 != pts1End && p2 != pts2End; ++p1, ++p2)
  {
    d += distance(*p1, *p2);
    size++;
  }

  return d / size;
}

GRPoint centroid(const_point_iter begin, const_point_iter end) throw() {
  GRFloat x = 0.0, y = 0.0;
  std::size_t size = 0;

  for (const_point_iter p = begin; p != end; ++p) {
    x += p->x; y += p->y;
    size++;
  }
  return GRPointMake(x/size, y/size);
}

GRRect boundingBox(const_point_iter begin, const_point_iter end) throw() {
  GRFloat minX = GRFLOAT_MAX, maxX = -GRFLOAT_MAX,
          minY = GRFLOAT_MAX, maxY = -GRFLOAT_MAX;

  for (const_point_iter p = begin; p != end; ++p) {
    if (p->x < minX) minX = p->x;
    if (p->x > maxX) maxX = p->x;
    if (p->y < minY) minY = p->y;
    if (p->y > maxY) maxY = p->y;
  }
  return GRRectMake(minX, minY, maxX - minX, maxY - minY);
}

void rotateByRadians(point_iter begin, point_iter end, double angleRadians) throw() {
  const GRPoint c = centroid(begin, end);
  const double cos_ = std::cos(angleRadians);
  const double sin_ = std::sin(angleRadians);

  for (point_iter p = begin; p != end; ++p) {
    const GRFloat dx = p->x - c.x;
    const GRFloat dy = p->y - c.y;

    p->x = dx * cos_ - dy * sin_ + c.x;
    p->y = dx * sin_ + dy * cos_ + c.y;
  }
}

void rotateByDegrees(point_iter begin, point_iter end, double angleDegrees) throw() {
  const double angleRadians = convertDegreeToRadian(angleDegrees);
  rotateByRadians(begin, end, angleRadians);
}

double angleInRadians(const GRPoint& start, const GRPoint& end, bool positiveOnly) throw() {
  double radians = 0.0;
  if (start.x != end.x) {
    radians = std::atan2(end.y - start.y, end.x - start.x);
  } else {
    // pure vertical movement
    if (end.y < start.y)
      radians = -M_PI_2; // -90 degrees is straight up
    else if (end.y > start.y)
      radians = M_PI_2; // 90 degrees is straight down
  }
  if (positiveOnly && radians < 0.0) {
    radians += M_PI * 2.0;
  }
  return radians;
}

} /* namespace GestureRecognizer */
