/*
 * geometry.cpp
 *
 *   Copyright (c) 2008  Takanori Ishikawa  <takanori.ishikawa@gmail.com>
 *
 *   Permission is hereby granted, free of charge, to any person obtaining a copy
 *   of this software and associated documentation files (the "Software"), to deal
 *   in the Software without restriction, including without limitation the rights
 *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *   copies of the Software, and to permit persons to whom the Software is
 *   furnished to do so, subject to the following conditions:
 *
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 *
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *   THE SOFTWARE.
 */

#include "./unittest.h"
#include <cmath>


namespace {

using namespace GestureRecognizer;
using namespace GestureRecognizer::Test;

#define DEG2RAD(d)  ((d) * M_PI / 180.0)
#define RAD2DEG(r)  ((r) * 180.0 / M_PI)

void test_convertDegreeToRadian() {
  for (int i = 0; i < 10; i++) {
    assertAlmostEqual(convertDegreeToRadian(30.0 * i), DEG2RAD(30.0 * i));
    assertAlmostEqual(convertDegreeToRadian(45.0 * i), DEG2RAD(45.0 * i));
  }
}

void test_convertRadianToDegree() {
  for (int i = 0; i < 10; i++) {
    assertAlmostEqual(convertRadianToDegree(10.0 * i), RAD2DEG(10.0 * i));
  }
}

void test_distance() {
  const GRPoint p1 = GRPointMake(0.0f, 0.0f);
  const GRPoint p2 = GRPointMake(100.0f, 100.0f);

  assertAlmostEqual(distance(p1, p2), sqrt(100.0 * 100.0 * 2.0));
  assertAlmostEqual(distance(p1, p1), 0.0);

  const GRPoint p3 = GRPointMake(-50.0f, -50.0f);
  const GRPoint p4 = GRPointMake( 50.0f,  50.0f);

  assertAlmostEqual(distance(p1, p2), distance(p3, p4));
}

void assertPathLengthOf(GRFloat expectedLength, GRFloat x1, GRFloat y1, GRFloat x2, GRFloat y2) {
  GRPoint points[2];
  const std::size_t n = ELEMENTS_SIZE(points);

  points[0] = GRPointMake(x1, y1);
  points[1] = GRPointMake(x2, y2);
  assertAlmostEqual(expectedLength, pathLength(points, points + n));
}

void test_pathLength() {
  assertPathLengthOf(0.0f,
    0.0f, 0.0f,
    0.0f, 0.0f);
  assertPathLengthOf(1.0f,
    1.0f, 0.0f,
    0.0f, 0.0f);
  assertPathLengthOf(1.0f,
    0.0f, -1.0f,
    0.0f,  0.0f);

  // Rectangle
  {
    GRPoint points[4];
    const std::size_t n = ELEMENTS_SIZE(points);

    points[0] = GRPointMake(-10.0f,  10.0f);
    points[1] = GRPointMake(-10.0f, -10.0f);
    points[2] = GRPointMake( 10.0f, -10.0f);
    points[3] = GRPointMake( 10.0f,  10.0f);

    assertAlmostEqual(60.0, pathLength(points, points + n));
  }
}

void test_pathDistance() {
  GRPoint path1[2], path2[2];
  const std::size_t n = ELEMENTS_SIZE(path1);
  assert(ELEMENTS_SIZE(path2) == n);

  path1[0] = GRPointMake(0.0f,  0.0f);
  path1[1] = GRPointMake(10.0f, 0.0f);

  path2[0] = GRPointMake(0.0f,  5.0f);
  path2[1] = GRPointMake(10.0f, 5.0f);

  assertAlmostEqual(5.0, pathDistance(path1, path1 + n, path2, path2 + n));

}

// GestureRecognizer::centroid
void test_centroid() {
  GRPoint points[4];
  const std::size_t n = ELEMENTS_SIZE(points);

  points[0] = GRPointMake(-10.0f, 10.0f);
  points[1] = GRPointMake(-10.0f,  0.0f);
  points[2] = GRPointMake( 10.0f,  0.0f);
  points[3] = GRPointMake( 10.0f, 10.0f);

  const GRPoint center = centroid(points, points+n);
  assertAlmostEqual(0.0, center.x);
  assertAlmostEqual(5.0, center.y);
}

// GestureRecognizer::boundingBox
void test_boundingBox() {
  GRPoint points[4];
  const std::size_t n = ELEMENTS_SIZE(points);

  points[0] = GRPointMake(-10.5f, 10.0f);
  points[1] = GRPointMake(-10.5f,  0.0f);
  points[2] = GRPointMake( 10.5f,  0.0f);
  points[3] = GRPointMake( 10.5f, 10.0f);

  const GRRect rect = boundingBox(points, points+n);
  assertAlmostEqual(-10.5, GRRectGetMinX(rect));
  assertAlmostEqual(  0.0, GRRectGetMinY(rect));
  assertAlmostEqual( 21.0, GRRectGetWidth(rect));
  assertAlmostEqual( 10.0, GRRectGetHeight(rect));
}

void test_boundingBox_min() {
  const GRPoint point = GRPointMake(0.0f, 0.0f);
  const GRRect rect = boundingBox(&point, &point+1);

  assertAlmostEqual(0.0, GRRectGetMinX(rect));
  assertAlmostEqual(0.0, GRRectGetMinY(rect));
  assertAlmostEqual(0.0, GRRectGetWidth(rect));
  assertAlmostEqual(0.0, GRRectGetHeight(rect));
}

// GestureRecognizer::RotateByRadians
// GestureRecognizer::RotateByDegrees
void test_rotation() {
  GRPoint points[2];
  const std::size_t n = ELEMENTS_SIZE(points);

  points[0] = GRPointMake( 10.0f, 0.0f);
  points[1] = GRPointMake(-10.0f, 0.0f);

  rotateByDegrees(points, points+n, 90.0);
  assertAlmostEqual( 0.0,  points[0].x);
  assertAlmostEqual(10.0,  points[0].y);
  assertAlmostEqual( 0.0,  points[1].x);
  assertAlmostEqual(-10.0, points[1].y);
}

void test_rotation_zero() {
  GRPoint point = GRPointMake(0.0f, 0.0f);

  for (int i = 0; i < 4; i++) {
    rotateByDegrees(&point, &point+1, 90.0 * i);
    assertAlmostEqual(0.0, point.x);
    assertAlmostEqual(0.0, point.y);
  }
}

void test_angleInRadians() {
  // zero
  GRPoint pts1 = GRPointMake(0.0f, 0.0f);
  GRPoint pts2 = GRPointMake(0.0f, 0.0f);
  assertAlmostEqual(0.0, angleInRadians(pts1, pts2));

  pts1 = GRPointMake(0.0f, 0.0f);
  pts2 = GRPointMake(1.0f, 0.0f);
  assertAlmostEqual(0.0, angleInRadians(pts1, pts2));

  // 90 degrees
  pts1 = GRPointMake(0.0f, 0.0f);
  pts2 = GRPointMake(0.0f, 1.0f);
  assertAlmostEqual(convertDegreeToRadian(90.0), angleInRadians(pts1, pts2));
}

} /* anonymous namespace */


namespace GestureRecognizer {
  namespace Test {

    void runUtilsTest() {
      test_convertDegreeToRadian();
      test_convertRadianToDegree();
      test_distance();
      test_pathLength();
      test_pathDistance();
      test_centroid();
      test_boundingBox();
      test_boundingBox_min();
      test_rotation();
      test_rotation_zero();
      test_angleInRadians();
    }

  } /* namespace Test */
} /* namespace GestureRecognizer */
