/*
 * unittest.h - Common header for tests
 *
 *   Copyright (c) 2008  Takanori Ishikawa  <takanori.ishikawa@gmail.com>
 *
 *   Permission is hereby granted, free of charge, to any person obtaining a copy
 *   of this software and associated documentation files (the "Software"), to deal
 *   in the Software without restriction, including without limitation the rights
 *   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 *   copies of the Software, and to permit persons to whom the Software is
 *   furnished to do so, subject to the following conditions:
 *
 *   The above copyright notice and this permission notice shall be included in
 *   all copies or substantial portions of the Software.
 *
 *   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 *   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 *   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 *   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 *   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 *   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 *   THE SOFTWARE.
 */

#ifndef DOLLAR_UNITTEST_H
#define DOLLAR_UNITTEST_H

#include <cstdio>
#include <cstdlib>
#include <cassert>
#include <cmath>
#include <limits>
#include <dollar.h>

// number of elements
#define ELEMENTS_SIZE(a)  (sizeof(a)/sizeof((a)[0]))


namespace GestureRecognizer {
  namespace Test {

    /** 
     * For Floating Point Fault Tolerance:
     * the number of floating-point rounding errors.
     *
     * Reference: The Test Tools: floating-point comparison algorithms
     * http://www.boost.org/doc/libs/1_34_1/libs/test/doc/components/test_tools/floating_point_comparison.html
     */
    static const double FPRoundingErrors = 10.0;

    /**
     * Compares two floating point numbers for almost equality.
     */
    template <typename T, typename U> bool AlmostEqual(T first, U second) throw() {
      return fabs(first - second) <= FPRoundingErrors * std::numeric_limits<T>::epsilon() / 2.0;
    }

    /**
     * Test that first and second are approximately equal by computing the difference,
     * and comparing. If the values do not compare equal, the test will fail.
     */
    template <typename T, typename U> void _assertAlmostEqual(
      T first, U second, const char *file, int lineno) throw()
    {
      if (!AlmostEqual(first, second)) {
        fprintf(stderr, "Expected %G, but was %G in %s:%d\n", first, second, file, lineno);
        abort();
      }
    }

    #define assertAlmostEqual(first, second)  GestureRecognizer::Test::_assertAlmostEqual((first), (second), __FILE__, __LINE__)


    extern void runAllTests();

  } /* namespace Test */
} /* namespace GestureRecognizer */


#endif /* DOLLAR_UNITTEST_H */
